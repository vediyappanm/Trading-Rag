---
name: trusted-accessibility-guardian
description: Build a complete Trusted Accessibility Guardian desktop prototype — a security monitoring system that detects malware exploiting accessibility APIs, uses ML-based ambient noise detection for environment context switching, and communicates alerts through audio/visual patterns for blind/low-vision users. This is a **laptop prototype** (not Android). Use this skill when building a local TAG demo, implementing real-time service monitoring with ML classification, creating an accessible web dashboard for threat detection, or prototyping accessibility API abuse detection systems. Full stack: Python FastAPI backend + SQLite, ML audio classifier with mic input, accessible HTML5 web UI, simulated process/service monitoring, and haptic/audio alert patterns.
---

# Trusted Accessibility Guardian — Laptop Prototype Skill

You are building **TAG (Trusted Accessibility Guardian)**: a desktop prototype that demonstrates detection of accessibility API abuse used by banking trojans like Cerberus, SharkBot, Xenomorph, and FluBot.

## Why This Matters

Banking trojans exploit Android's AccessibilityService to read screens, steal credentials, intercept OTPs, and approve fraudulent transfers. Blind users are disproportionately affected because they must enable accessibility services, making them unable to distinguish legitimate services from malware.

TAG demonstrates a monitoring approach that detects unauthorized accessibility services via whitelist verification, environmental context switching via ML noise classification, and accessible alert patterns (haptic + audio + visual) so users can stay secure without public announcements.

## Laptop Prototype Architecture

This is **a working demo** you can run locally in ~1 hour. It demonstrates all core concepts without needing an Android device.

```
┌─────────────────────────────────────────┐
│     Web UI (http://localhost:8000)      │
│  ┌────────────────┐  ┌───────────────┐ │
│  │ Dashboard      │  │ Alert History │ │
│  │ (threat stats) │  │ (logs)        │ │
│  └────────┬───────┘  └───────────────┘ │
│           │                             │
│           ▼                             │
│  ┌─────────────────────────────────┐   │
│  │ FastAPI Backend (port 8000)     │   │
│  │ ├─ GET  /api/services           │   │
│  │ ├─ POST /api/scan               │   │
│  │ ├─ POST /api/alerts/{id}/ack    │   │
│  │ └─ GET  /api/ml/environment     │   │
│  └──┬──────────────────────────────┘   │
├────┼──────────────────────────────────┤
│    │                                   │
│    ▼                                   │
│  ┌──────────────────────────────────┐ │
│  │ Core Modules (Python)            │ │
│  │ ├─ ProcessMonitor                │ │
│  │ ├─ ServiceVerifier (whitelist)   │ │
│  │ ├─ NoiseClassifier (TensorFlow)  │ │
│  │ ├─ ThreatAssessment              │ │
│  │ └─ AlertEngine (audio+visual)    │ │
│  └──┬───────────────────────────────┘ │
├────┼──────────────────────────────────┤
│    │                                   │
│    ▼                                   │
│  ┌──────────────────────────────────┐ │
│  │ Data Layer (SQLite)              │ │
│  │ ├─ Whitelist Registry            │ │
│  │ ├─ Process/Service Logs          │ │
│  │ ├─ Alert History                 │ │
│  │ └─ ML Model (embedded)           │ │
│  └──────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

Three layers, all running locally:
1. **Web UI** (HTML5 + JavaScript) — Accessible dashboard showing detected services, threat level, environment mode
2. **FastAPI Backend** — Real-time monitoring API, whitelist verification, threat scoring
3. **ML + Monitoring** — Audio classifier for environment detection (public vs private), simulated process/service monitoring

## Quick Start — Run the Prototype

**Prerequisites:**
- Python 3.10+
- pip

**Setup (5 minutes):**

```bash
cd trusted-accessibility-guardian
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Download and cache ML model (~100MB, one-time)
python -c "from models.audio_classifier import NoiseClassifier; NoiseClassifier.download_model()"

# Start the backend
python main.py
```

**Access the UI:**
Open http://localhost:8000 in your browser. You'll see a live dashboard with:
- Currently active "services" (simulated processes)
- Threat assessment with risk scores
- Environment detection (public/private based on mic input)
- Alert history
- Manual scan button

Read `references/setup.md` for detailed setup, environment variables, and troubleshooting.

## Project Structure

```
trusted-accessibility-guardian/
├── main.py                           # FastAPI server entry point
├── requirements.txt                  # Python dependencies
├── config.py                         # Settings (DATABASE_URL, LOG_LEVEL, etc.)
├── database.py                       # SQLite setup + schemas
├── static/
│   ├── index.html                    # Web UI (served by FastAPI)
│   ├── css/
│   │   └── style.css                 # Tailwind + accessible styling
│   └── js/
│       └── app.js                    # Real-time dashboard + WebSocket listener
├── app/
│   ├── models.py                     # Pydantic schemas (Service, Alert, etc.)
│   ├── routers/
│   │   ├── services.py               # GET /api/services (current monitored services)
│   │   ├── scanning.py               # POST /api/scan (trigger a scan)
│   │   ├── alerts.py                 # GET /api/alerts, POST /api/alerts/{id}/ack
│   │   └── ml.py                     # GET /api/ml/environment (current env detection)
│   └── services/
│       ├── process_monitor.py        # Simulated or real process enumeration
│       ├── whitelist.py              # Whitelist checking against known-good services
│       ├── threat_assessment.py      # Risk scoring
│       ├── alerts.py                 # Alert queuing and broadcasting
│       └── background_scanner.py     # Asyncio background task
├── models/
│   ├── audio_classifier.py           # TensorFlow Lite noise classifier
│   ├── train_classifier.py           # Training script (ESC-50 + UrbanSound8K)
│   └── noise_classifier.tflite       # Pre-trained model (auto-downloaded)
└── references/
    ├── setup.md
    ├── process-monitor.md
    ├── alert-system.md
    ├── ml-pipeline.md
    ├── backend-api.md
    └── web-ui.md
```

## Phase 1: Backend Setup & Core Monitoring

Read `references/backend-api.md` for full API implementation with examples. Start with:

1. **FastAPI server** (`main.py`) listening on `http://localhost:8000`
2. **SQLite database** with tables for services, alerts, whitelist
3. **Process monitoring** that simulates or detects active services
4. **Whitelist verification** against known-good services (TalkBack, Voice Access, etc.)

## Phase 2: Alert System

Read `references/alert-system.md` for alert pattern implementations. The system:

1. **Queues alerts by priority** (emergency > critical > warning > info > safe)
2. **Plays audio tones** (sine waves at different frequencies for each threat level)
3. **Displays visual indicators** (color-coded badges, flashing icons)
4. **Broadcasts via WebSocket** to connected clients for real-time UI updates
5. **Logs to SQLite** for history and auditability

**Alert Threat Levels:**
| Level | Meaning | Audio Tone | Visual |
|-------|---------|-----------|--------|
| **Safe** | All services verified | C4 (262 Hz) chirp | Green checkmark |
| **Info** | New service detected | E4 (330 Hz) chirp | Blue info icon |
| **Warning** | Unknown service | G4 (392 Hz) low tone | Yellow caution icon |
| **Critical** | Suspicious service | A3 (220 Hz) + A4 (440 Hz) | Red alert icon |
| **Emergency** | Malware detected | SOS pattern (S-O-S tones) | Red flashing background |

## Phase 3: ML Ambient Noise Detection

The ML model classifies the user's environment as **public** or **private** to auto-switch between audio-only alerts and audio+visual alerts.

### Model

A lightweight TensorFlow Lite classifier (< 2MB):
- **Input**: 1-second audio window, Mel spectrogram (64 bands x 44 frames)
- **Architecture**: Conv2D → BatchNorm → ReLU → MaxPool → Dense(64) → Softmax(2)
- **Output**: [public_probability, private_probability]

### Training Data

Pre-trained on ESC-50 + UrbanSound8K, relabeled into two classes:
- **Public**: traffic, crowds, restaurants, trains, parks
- **Private**: quiet rooms, appliances, typing, single-person speech

### On-Device Inference

Runs every 30 seconds on 1-second mic windows. Uses PyAudio for mic input, TensorFlow Lite for inference.

Read `references/ml-pipeline.md` for training script and on-device inference code.

## Phase 4: Web UI — Accessible Dashboard

The HTML5 dashboard served by FastAPI at `http://localhost:8000` includes:

### Key Features

1. **Real-time Service List** — Shows currently detected services with status badges
2. **Threat Gauge** — Visual indicator of current threat level (0-100)
3. **Environment Status** — Current ML classification (Public/Private)
4. **Alert History** — Scrollable log of recent alerts with timestamps
5. **Manual Scan Button** — Trigger an immediate monitoring scan
6. **Accessibility Features**:
   - ARIA landmarks (`<main>`, `<aside>`, `<nav>`)
   - Semantic HTML5 (`<header>`, `<section>`, `<button>`)
   - High contrast (WCAG AAA 7:1 minimum)
   - Screen reader announcements via ARIA live regions
   - Full keyboard navigation (Tab, Enter, Space, Escape)
   - Large touch targets (≥56px)

### Dashboard Screenshot (Conceptual)

```
┌────────────────────────────────────────┐
│  TAG Guardian — Status Dashboard       │
├────────────────────────────────────────┤
│                                        │
│  Current Threat Level:                 │
│  ████░░░░░░░░░░░░░░░░ 35% (LOW)        │
│                                        │
│  Environment: PRIVATE [🔇 mic active]  │
│  Mode: Voice + Visual Alerts           │
│                                        │
├────────────────────────────────────────┤
│  Active Services (3)                   │
│  ─────────────────                     │
│  ✓ com.google.android.marvin.talkback  │
│    TalkBack (verified)                 │
│                                        │
│  ✓ com.samsung.accessibility           │
│    Samsung Voice Assistant (verified)  │
│                                        │
│  ? com.unknown.service                 │
│    UNKNOWN SERVICE - Review Needed     │
│                                        │
├────────────────────────────────────────┤
│  [Scan Now]                            │
│  [View Alert History]                  │
│  [Settings]                            │
├────────────────────────────────────────┤
│  Last scan: 2 minutes ago              │
└────────────────────────────────────────┘
```

Read `references/web-ui.md` for complete HTML + CSS + JavaScript implementation.

## Build Order — 5 Sprints (Each ~1-2 hours)

### Sprint 1 (30 min): FastAPI Backend + Database

1. Create `main.py` with FastAPI server, SQLite connection
2. Define SQLAlchemy models: `Service`, `Alert`, `WhitelistEntry`, `ScanLog`
3. Implement basic route: `GET /api/services` (returns mock services list)
4. Test with `curl http://localhost:8000/api/services`

**Deliverable**: Server running, database initialized, `/api/services` returns JSON.

### Sprint 2 (30 min): Process Monitoring + Whitelist Verification

5. Implement `ProcessMonitor` — simulate or enumerate active processes
6. Implement `ServiceVerifier` — check package names against whitelist
7. Implement `ThreatAssessment` — score each service (0-100)
8. Add `POST /api/scan` endpoint that triggers a scan and saves results

**Deliverable**: Running `POST http://localhost:8000/api/scan` returns threat assessment JSON.

### Sprint 3 (30 min): Alert System + WebSocket

9. Implement `AlertEngine` — audio playback (sine waves), visual styling
10. Add WebSocket endpoint: `ws://localhost:8000/ws/alerts`
11. Broadcast alerts to connected clients when threats detected
12. Add `GET /api/alerts` and `POST /api/alerts/{id}/ack` endpoints

**Deliverable**: Alerts broadcast to browser, play audio tones on client.

### Sprint 4 (45 min): ML Noise Classifier

13. Download pre-trained model or use model registry to auto-download
14. Implement `NoiseClassifier` with TensorFlow Lite inference
15. Set up `PyAudio` mic input, process 1-second windows
16. Add `GET /api/ml/environment` endpoint returning `{public_prob: 0.8, private_prob: 0.2}`
17. Run background task that updates environment classification every 30s

**Deliverable**: `GET /api/ml/environment` returns current environment classification.

### Sprint 5 (45 min): Web UI + Accessibility Polish

18. Create `static/index.html` with Tailwind CSS + accessible structure
19. Implement dashboard: service list, threat gauge, environment status, alert history
20. Add JavaScript WebSocket listener for real-time alert updates
21. Implement ARIA live regions, keyboard navigation, high-contrast mode
22. Test with screen reader (NVDA on Windows, VoiceOver on Mac)

**Deliverable**: Dashboard at http://localhost:8000 fully functional and accessible.

## Implementation Details

Read these reference files for complete code samples:

- **`references/setup.md`** — Installation, dependencies, environment variables, troubleshooting
- **`references/process-monitor.md`** — How to enumerate processes or simulate services (mock data)
- **`references/alert-system.md`** — Audio tone generation (PyAudio + numpy), WebSocket broadcasting
- **`references/ml-pipeline.md`** — TensorFlow Lite model download, mic input, inference loop
- **`references/backend-api.md`** — FastAPI routes, SQLAlchemy models, database initialization
- **`references/web-ui.md`** — HTML5 dashboard, CSS (Tailwind), JavaScript (fetch API + WebSocket)
