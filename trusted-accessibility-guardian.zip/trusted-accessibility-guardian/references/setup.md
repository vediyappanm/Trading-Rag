# Setup Guide — TAG Laptop Prototype

## Prerequisites

- **Python 3.10+** ([python.org](https://www.python.org/downloads/))
- **pip** (included with Python)
- **Microphone** (for ML noise detection)
- **Modern browser** (Chrome, Firefox, Edge) for web UI

## Installation (5 minutes)

```bash
# Navigate to project directory
cd trusted-accessibility-guardian

# Create virtual environment
python -m venv venv

# Activate it
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Download ML model (auto-cached, ~100MB, one-time)
python -c "from models.audio_classifier import NoiseClassifier; NoiseClassifier.download_model()"
```

## Running the Application

```bash
# Make sure venv is activated
source venv/bin/activate  # or: venv\Scripts\activate on Windows

# Start the server
python main.py
```

You should see:
```
INFO:     Uvicorn running on http://127.0.0.1:8000
```

Open http://localhost:8000 in your browser.

## Configuration

Create a `.env` file in the project root:

```env
# Database
DATABASE_URL=sqlite:///./tag.db

# Logging
LOG_LEVEL=INFO

# ML Model
ML_MODEL_CACHE_DIR=./models/cache
ML_INFERENCE_INTERVAL_SECONDS=30

# Monitoring
SCAN_INTERVAL_SECONDS=60

# UI
WEB_UI_PORT=8000
```

**Default values work fine for local development.**

## Troubleshooting

### "No module named 'fastapi'"
```bash
pip install -r requirements.txt
```

### "Uvicorn not found"
```bash
pip install uvicorn
```

### Microphone not detected
- Check Windows/macOS/Linux sound settings
- Ensure "Input Device" is set correctly in system audio settings
- Run: `python -c "import sounddevice; print(sounddevice.query_devices())"`
  to see available mic devices

### Port 8000 already in use
```bash
# Use a different port
python main.py --port 8001
```
Then open http://localhost:8001

### Database locked error
```bash
# Delete the old database and start fresh
rm tag.db
python main.py
```

## File Structure

```
trusted-accessibility-guardian/
├── main.py                  # FastAPI entry point
├── config.py                # Configuration loading
├── database.py              # SQLite + SQLAlchemy setup
├── requirements.txt         # Dependencies
├── .env                      # Configuration (optional, create as needed)
├── tag.db                    # SQLite database (auto-created)
├── static/
│   ├── index.html           # Main dashboard
│   ├── css/style.css        # Styling
│   └── js/app.js            # Frontend logic
├── app/
│   ├── models.py            # Pydantic schemas
│   ├── routers/
│   │   ├── services.py      # Service monitoring endpoints
│   │   ├── scanning.py      # Scan triggers
│   │   ├── alerts.py        # Alert management
│   │   └── ml.py            # ML inference endpoints
│   └── services/
│       ├── process_monitor.py     # Service detection
│       ├── whitelist.py           # Verification logic
│       ├── threat_assessment.py   # Risk scoring
│       ├── alerts.py              # Alert queuing
│       └── background_scanner.py  # Async monitoring
├── models/
│   ├── audio_classifier.py  # TFLite model inference
│   ├── train_classifier.py  # Training script (optional)
│   └── noise_classifier.tflite  # Pre-trained model
└── references/
    ├── setup.md
    ├── process-monitor.md
    ├── alert-system.md
    ├── ml-pipeline.md
    ├── backend-api.md
    └── web-ui.md
```

## Development Workflow

### Making Code Changes

1. Edit a file (e.g., `app/services/threat_assessment.py`)
2. The FastAPI dev server auto-reloads (watches for file changes)
3. Refresh your browser to see changes
4. Check the terminal for any errors

### Running Tests

```bash
# Install pytest
pip install pytest pytest-asyncio

# Run all tests
pytest

# Run a specific test file
pytest tests/test_whitelist.py

# Run with coverage
pytest --cov=app --cov=models
```

### Debugging

Use Python's built-in `pdb`:

```python
def some_function():
    x = 42
    breakpoint()  # Execution pauses here
    return x
```

Or install `ipdb` for a nicer interface:

```bash
pip install ipdb
# Then use: breakpoint() in your code, it'll use ipdb automatically
```

## Simulating Threats

The prototype includes mock services for testing. To add a suspicious service:

1. Edit `app/services/process_monitor.py`
2. Add to the `MOCK_SERVICES` list:
   ```python
   MockService(
       name="com.suspicious.malware",
       package_name="com.suspicious.malware",
       category="unknown",
       is_verified=False,
       risk_score=85  # High risk
   )
   ```
3. Restart the server: the dashboard will immediately show it

## Next Steps

- Read `references/backend-api.md` to understand the API structure
- Read `references/web-ui.md` to learn the frontend
- Read `references/ml-pipeline.md` to understand the audio classifier
- Run `python main.py` and open http://localhost:8000
