# Web UI — Accessible Dashboard

## Main Dashboard (static/index.html)

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAG Guardian — Security Dashboard</title>
    <link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
    <div class="skip-to-main">
        <a href="#main-content">Skip to main content</a>
    </div>

    <header role="banner">
        <h1>TAG Guardian</h1>
        <p class="subtitle">Accessibility Service Threat Monitor</p>
    </header>

    <nav aria-label="Main navigation">
        <ul>
            <li><a href="#" class="active" data-page="dashboard">Dashboard</a></li>
            <li><a href="#" data-page="services">Services</a></li>
            <li><a href="#" data-page="alerts">Alert History</a></li>
            <li><a href="#" data-page="settings">Settings</a></li>
        </ul>
    </nav>

    <main id="main-content">
        <!-- Dashboard Page -->
        <section id="dashboard" class="page active" aria-labelledby="dashboard-heading">
            <h2 id="dashboard-heading">Dashboard</h2>

            <!-- Status Card -->
            <article class="card card-status">
                <h3>Current Status</h3>
                <div class="status-indicator" id="threat-level">
                    <div class="gauge">
                        <div class="gauge-fill" id="threat-gauge"></div>
                    </div>
                    <p id="threat-text">Threat Level: <strong>Low</strong> (35%)</p>
                </div>

                <div class="status-grid">
                    <div class="status-item">
                        <span class="label">Active Services:</span>
                        <span id="service-count" class="value">3</span>
                    </div>
                    <div class="status-item">
                        <span class="label">Verified:</span>
                        <span id="verified-count" class="value">3</span>
                    </div>
                    <div class="status-item">
                        <span class="label">Unknown:</span>
                        <span id="unknown-count" class="value">0</span>
                    </div>
                </div>
            </article>

            <!-- Environment Card -->
            <article class="card card-environment">
                <h3>Environment Detection</h3>
                <div id="environment-display">
                    <p id="environment-status">Analyzing...</p>
                    <progress id="environment-confidence" value="0" max="100"></progress>
                    <p class="small-text">
                        Public: <span id="public-prob">—</span>% |
                        Private: <span id="private-prob">—</span>%
                    </p>
                </div>
                <p id="alert-mode-info" class="info">
                    <strong>Alert Mode:</strong> Voice + Visual
                </p>
            </article>

            <!-- Services List -->
            <article class="card card-services">
                <h3>Active Services</h3>
                <button id="scan-button" class="btn btn-primary">Scan Now</button>

                <ul id="services-list" role="list">
                    <!-- Populated by JavaScript -->
                </ul>
            </article>

            <!-- Alert History (Compact) -->
            <article class="card card-alerts">
                <h3>Recent Alerts</h3>
                <ul id="alerts-list" role="list">
                    <!-- Populated by JavaScript -->
                </ul>
                <a href="#" data-page="alerts" class="link">View all alerts →</a>
            </article>
        </section>

        <!-- Services Page -->
        <section id="services" class="page" aria-labelledby="services-heading">
            <h2 id="services-heading">Accessibility Services</h2>
            <div id="services-detail">
                <!-- Populated by JavaScript -->
            </div>
        </section>

        <!-- Alert History Page -->
        <section id="alerts" class="page" aria-labelledby="alerts-heading">
            <h2 id="alerts-heading">Alert History</h2>
            <table id="alerts-table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Service</th>
                        <th>Threat Level</th>
                        <th>Message</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="alerts-tbody">
                    <!-- Populated by JavaScript -->
                </tbody>
            </table>
        </section>

        <!-- Settings Page -->
        <section id="settings" class="page" aria-labelledby="settings-heading">
            <h2 id="settings-heading">Settings</h2>
            <form class="settings-form">
                <fieldset>
                    <legend>Alert Preferences</legend>

                    <label>
                        <input type="checkbox" id="audio-alerts" checked />
                        Enable audio alerts
                    </label>

                    <label>
                        <input type="checkbox" id="visual-alerts" checked />
                        Enable visual alerts
                    </label>

                    <label for="scan-interval">
                        Scan Interval (seconds):
                        <input type="number" id="scan-interval" value="60" min="10" />
                    </label>
                </fieldset>

                <fieldset>
                    <legend>About</legend>
                    <p>TAG Guardian v0.1.0</p>
                    <p><a href="https://example.com/docs">Documentation</a></p>
                </fieldset>
            </form>
        </section>
    </main>

    <footer>
        <p>TAG Guardian — Accessibility Security Monitor</p>
    </footer>

    <script src="/static/js/app.js"></script>
</body>
</html>
```

## Styles (static/css/style.css)

```css
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --color-primary: #3b82f6;
    --color-success: #10b981;
    --color-warning: #f59e0b;
    --color-danger: #ef4444;
    --color-dark: #1f2937;
    --color-light: #f9fafb;
    --color-border: #e5e7eb;

    --font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    --font-size-base: 16px;
    --line-height: 1.6;

    --space-xs: 0.5rem;
    --space-sm: 1rem;
    --space-md: 1.5rem;
    --space-lg: 2rem;
    --space-xl: 3rem;

    --border-radius: 8px;
    --shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.1);
}

/* High Contrast Mode */
@media (prefers-contrast: more) {
    :root {
        --color-primary: #0c4a9e;
        --color-dark: #000;
        --color-light: #fff;
    }

    * {
        border-width: 2px !important;
    }
}

/* Dark Mode */
@media (prefers-color-scheme: dark) {
    :root {
        --color-dark: #f9fafb;
        --color-light: #1f2937;
        --color-border: #374151;
    }
}

body {
    font-family: var(--font-family);
    font-size: var(--font-size-base);
    line-height: var(--line-height);
    color: var(--color-dark);
    background: var(--color-light);
}

header {
    background: linear-gradient(135deg, var(--color-primary) 0%, #1e40af 100%);
    color: white;
    padding: var(--space-lg);
    box-shadow: var(--shadow-lg);
}

header h1 {
    font-size: 2rem;
    margin-bottom: var(--space-xs);
}

header .subtitle {
    opacity: 0.9;
    font-size: 0.95rem;
}

/* Navigation */
nav {
    background: white;
    border-bottom: 1px solid var(--color-border);
    padding: var(--space-sm);
    display: flex;
    gap: var(--space-md);
    overflow-x: auto;
}

nav ul {
    list-style: none;
    display: flex;
    gap: var(--space-md);
}

nav a {
    padding: var(--space-sm) var(--space-md);
    text-decoration: none;
    color: var(--color-dark);
    border-bottom: 3px solid transparent;
    transition: border-color 0.3s;
}

nav a:hover, nav a.active {
    border-bottom-color: var(--color-primary);
    color: var(--color-primary);
}

/* Focus visible for keyboard navigation */
*:focus-visible {
    outline: 3px solid var(--color-primary);
    outline-offset: 2px;
}

/* Main Content */
main {
    max-width: 1200px;
    margin: 0 auto;
    padding: var(--space-lg);
}

.page {
    display: none;
}

.page.active {
    display: block;
}

/* Cards */
.card {
    background: white;
    border: 1px solid var(--color-border);
    border-radius: var(--border-radius);
    padding: var(--space-md);
    margin-bottom: var(--space-lg);
    box-shadow: var(--shadow);
}

.card h3 {
    font-size: 1.25rem;
    margin-bottom: var(--space-md);
}

/* Status Card */
.card-status {
    background: linear-gradient(135deg, #e0f2fe 0%, #ecfdf5 100%);
}

.gauge {
    width: 100%;
    height: 30px;
    background: #e5e7eb;
    border-radius: var(--border-radius);
    overflow: hidden;
    margin-bottom: var(--space-md);
}

.gauge-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--color-success), var(--color-warning), var(--color-danger));
    width: 35%;
    transition: width 0.3s;
}

.status-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: var(--space-md);
    margin-top: var(--space-md);
}

.status-item {
    display: flex;
    justify-content: space-between;
    padding: var(--space-sm);
    background: rgba(255, 255, 255, 0.8);
    border-radius: 4px;
}

.status-item .label {
    font-weight: 600;
}

.status-item .value {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--color-primary);
}

/* Services List */
#services-list {
    list-style: none;
}

#services-list li {
    padding: var(--space-md);
    border: 1px solid var(--color-border);
    border-radius: 4px;
    margin-bottom: var(--space-sm);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.service-status {
    display: flex;
    gap: var(--space-sm);
    align-items: center;
}

.service-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.85rem;
    font-weight: 600;
}

.badge-verified {
    background: var(--color-success);
    color: white;
}

.badge-unknown {
    background: var(--color-warning);
    color: white;
}

.badge-suspicious {
    background: var(--color-danger);
    color: white;
    animation: pulse 0.5s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.7; }
}

/* Buttons */
.btn {
    padding: var(--space-sm) var(--space-md);
    border: none;
    border-radius: var(--border-radius);
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s;
    font-weight: 600;
    min-height: 44px;  /* Touch-friendly */
}

.btn-primary {
    background: var(--color-primary);
    color: white;
}

.btn-primary:hover {
    background: #1e40af;
}

.btn-primary:active {
    transform: scale(0.98);
}

/* Table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: var(--space-lg);
}

thead {
    background: var(--color-light);
    border-bottom: 2px solid var(--color-border);
}

th {
    text-align: left;
    padding: var(--space-md);
    font-weight: 600;
}

td {
    padding: var(--space-md);
    border-bottom: 1px solid var(--color-border);
}

/* Forms */
fieldset {
    border: 1px solid var(--color-border);
    border-radius: var(--border-radius);
    padding: var(--space-md);
    margin-bottom: var(--space-lg);
}

legend {
    font-weight: 600;
    padding: 0 var(--space-sm);
}

label {
    display: block;
    margin-bottom: var(--space-sm);
    cursor: pointer;
}

input[type="checkbox"] {
    margin-right: var(--space-sm);
}

input[type="number"] {
    width: 100px;
    padding: var(--space-sm);
    border: 1px solid var(--color-border);
    border-radius: 4px;
}

/* Links */
a {
    color: var(--color-primary);
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:visited {
    color: #7c3aed;
}

/* Footer */
footer {
    background: var(--color-dark);
    color: white;
    padding: var(--space-lg);
    text-align: center;
    margin-top: var(--space-xl);
}

/* Skip to main content link */
.skip-to-main {
    position: absolute;
    top: -40px;
    left: 0;
    background: var(--color-primary);
    color: white;
    padding: 8px;
    z-index: 100;
}

.skip-to-main:focus-within {
    top: 0;
}

/* Accessibility */
@media (max-width: 768px) {
    header h1 {
        font-size: 1.5rem;
    }

    .status-grid {
        grid-template-columns: 1fr;
    }

    main {
        padding: var(--space-md);
    }
}

/* Screen reader only */
.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0;
}
```

## Frontend Logic (static/js/app.js)

```javascript
// TAG Guardian Frontend
const API_BASE = 'http://localhost:8000';
let ws = null;

// Page Navigation
document.querySelectorAll('nav a').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = link.dataset.page;
        showPage(page);
        document.querySelectorAll('nav a').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
    });
});

function showPage(pageName) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageName).classList.add('active');
}

// Connect to WebSocket for real-time alerts
function connectWebSocket() {
    ws = new WebSocket('ws://localhost:8000/ws/alerts');

    ws.onmessage = (event) => {
        const alert = JSON.parse(event.data);
        handleAlert(alert);
    };

    ws.onerror = (e) => console.error('WebSocket error:', e);
    ws.onclose = () => setTimeout(connectWebSocket, 3000); // Reconnect after 3s
}

function handleAlert(alert) {
    console.log('Alert:', alert);
    updateThreatLevel(alert.threat_level);
    playAlertSound(alert.threat_level);
    addAlertToHistory(alert);
}

// Load Dashboard Data
async function loadDashboard() {
    try {
        // Get services
        const servicesRes = await fetch(`${API_BASE}/api/services`);
        const services = await servicesRes.json();

        // Get environment
        const envRes = await fetch(`${API_BASE}/api/ml/environment`);
        const env = await envRes.json();

        // Update UI
        updateServicesList(services);
        updateEnvironmentDisplay(env);
        updateAlertHistory();
    } catch (e) {
        console.error('Error loading dashboard:', e);
    }
}

function updateServicesList(services) {
    const list = document.getElementById('services-list');
    const verified = services.filter(s => s.is_verified).length;
    const unknown = services.filter(s => !s.is_verified).length;

    document.getElementById('service-count').textContent = services.length;
    document.getElementById('verified-count').textContent = verified;
    document.getElementById('unknown-count').textContent = unknown;

    list.innerHTML = services.map(s => `
        <li>
            <div>
                <strong>${s.app_name}</strong>
                <br>
                <small>${s.package_name}</small>
            </div>
            <span class="service-badge ${s.is_verified ? 'badge-verified' : 'badge-unknown'}">
                ${s.is_verified ? '✓ Verified' : '⚠ Unknown'}
            </span>
        </li>
    `).join('');
}

function updateEnvironmentDisplay(env) {
    document.getElementById('environment-status').textContent =
        env.classification === 'public' ? 'Public Environment Detected' : 'Private Environment Detected';
    document.getElementById('public-prob').textContent = (env.public_probability * 100).toFixed(0);
    document.getElementById('private-prob').textContent = (env.private_probability * 100).toFixed(0);
    document.getElementById('environment-confidence').value = (env.confidence * 100);

    const alertMode = env.classification === 'public' ? 'Haptic Only' : 'Voice + Visual';
    document.getElementById('alert-mode-info').textContent = `Alert Mode: ${alertMode}`;
}

async function updateAlertHistory() {
    try {
        const res = await fetch(`${API_BASE}/api/alerts?limit=5`);
        const alerts = await res.json();

        const list = document.getElementById('alerts-list');
        list.innerHTML = alerts.map(a => `
            <li>
                <strong>${a.threat_level.toUpperCase()}</strong> — ${a.message}
                <br>
                <small>${new Date(a.created_at).toLocaleString()}</small>
            </li>
        `).join('');
    } catch (e) {
        console.error('Error loading alerts:', e);
    }
}

function updateThreatLevel(threatLevel) {
    const scoreMap = { safe: 0, info: 25, warning: 50, critical: 75, emergency: 100 };
    const score = scoreMap[threatLevel] || 50;

    document.getElementById('threat-gauge').style.width = score + '%';
    document.getElementById('threat-text').textContent =
        `Threat Level: ${threatLevel.charAt(0).toUpperCase() + threatLevel.slice(1)} (${score}%)`;
}

function playAlertSound(threatLevel) {
    // Play audio notification (simplified version)
    // Full implementation in app/services/alerts.py
    console.log(`Playing ${threatLevel} alert sound`);
}

function addAlertToHistory(alert) {
    // Add to the alert history log
    const list = document.getElementById('alerts-list');
    const item = document.createElement('li');
    item.innerHTML = `
        <strong>${alert.threat_level.toUpperCase()}</strong> — ${alert.message}
        <br>
        <small>${new Date().toLocaleString()}</small>
    `;
    list.insertBefore(item, list.firstChild);
    if (list.children.length > 5) list.removeChild(list.lastChild);
}

// Scan Button
document.getElementById('scan-button').addEventListener('click', async () => {
    try {
        const res = await fetch(`${API_BASE}/api/scan`, { method: 'POST' });
        const result = await res.json();
        updateThreatLevel(result.threat_level);
        await loadDashboard();
    } catch (e) {
        console.error('Scan failed:', e);
    }
});

// Initialize
connectWebSocket();
loadDashboard();
setInterval(loadDashboard, 5000); // Refresh every 5 seconds
```

This provides a fully functional, accessible web dashboard for the TAG prototype.
