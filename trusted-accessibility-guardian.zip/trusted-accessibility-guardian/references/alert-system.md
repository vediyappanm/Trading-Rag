# Alert System — Audio + Visual Notifications

## Alert Patterns

TAG uses five distinct alert levels with corresponding audio tones and visual indicators:

| Level | Audio | Visual | Use Case |
|-------|-------|--------|----------|
| **Safe** | C4 (262 Hz) chirp | ✓ Green checkmark | All services verified |
| **Info** | E4 (330 Hz) chirp | ℹ Blue info icon | New service detected |
| **Warning** | G4 (392 Hz) low | ⚠ Yellow caution | Unknown service found |
| **Critical** | A3+A4 (220+440 Hz) | 🔴 Red alert | Suspicious service detected |
| **Emergency** | SOS pattern | 🔴 Flashing red | Malware likely active |

## Audio Generation (app/services/alerts.py)

```python
import numpy as np
import sounddevice as sd
import threading
from enum import Enum

class ThreatLevel(str, Enum):
    SAFE = "safe"
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"

class AudioAlert:
    """Generate and play alert audio tones"""

    def __init__(self, sample_rate: int = 44100):
        self.sample_rate = sample_rate

    def generate_tone(self, frequency: float, duration: float, amplitude: float = 0.3) -> np.ndarray:
        """Generate a sine wave tone"""
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        wave = amplitude * np.sin(2 * np.pi * frequency * t)
        return wave.astype(np.float32)

    def generate_chirp(self, start_freq: float, end_freq: float, duration: float) -> np.ndarray:
        """Generate a chirping tone (frequency sweep)"""
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        # Exponential frequency sweep
        freq = start_freq * (end_freq / start_freq) ** (t / duration)
        phase = 2 * np.pi * (start_freq * duration / np.log(end_freq / start_freq)) * (
            np.exp(np.log(end_freq / start_freq) * t / duration) - 1
        )
        wave = 0.3 * np.sin(phase)
        return wave.astype(np.float32)

    def play_safe(self):
        """Two short C4 chirps — 'all clear'"""
        tone = self.generate_chirp(262, 330, 0.1)  # C4 to E4 sweep
        silence = np.zeros(int(self.sample_rate * 0.05), dtype=np.float32)
        audio = np.concatenate([tone, silence, tone])
        self._play(audio)

    def play_info(self):
        """Three E4 taps — 'checking'"""
        tone = self.generate_tone(330, 0.08)
        silence = np.zeros(int(self.sample_rate * 0.05), dtype=np.float32)
        audio = np.concatenate([tone, silence, tone, silence, tone])
        self._play(audio)

    def play_warning(self):
        """G4 long-short-long — 'needs attention'"""
        long = self.generate_tone(392, 0.25)
        short = self.generate_tone(392, 0.1)
        silence = np.zeros(int(self.sample_rate * 0.1), dtype=np.float32)
        audio = np.concatenate([long, silence, short, silence, long])
        self._play(audio)

    def play_critical(self):
        """A3 + A4 alternating — 'urgent'"""
        a3 = self.generate_tone(220, 0.15)
        a4 = self.generate_tone(440, 0.15)
        silence = np.zeros(int(self.sample_rate * 0.1), dtype=np.float32)
        audio = np.concatenate([a3, silence, a4, silence, a3, silence, a4])
        self._play(audio)

    def play_emergency(self):
        """SOS pattern (3x rapid) — distress signal"""
        s = self.generate_tone(600, 0.1)
        o = self.generate_tone(600, 0.3)
        gap = np.zeros(int(self.sample_rate * 0.1), dtype=np.float32)
        letter_gap = np.zeros(int(self.sample_rate * 0.2), dtype=np.float32)

        # S: ···
        s_pattern = np.concatenate([s, gap, s, gap, s])
        # O: ───
        o_pattern = np.concatenate([o, gap, o, gap, o])
        # S: ···
        s_pattern2 = np.concatenate([s, gap, s, gap, s])

        audio = np.concatenate([s_pattern, letter_gap, o_pattern, letter_gap, s_pattern2])
        self._play(audio)

    def _play(self, audio: np.ndarray):
        """Play audio in a background thread"""
        def _play_thread():
            try:
                sd.play(audio, self.sample_rate)
                sd.wait()
            except Exception as e:
                print(f"Audio playback error: {e}")

        thread = threading.Thread(target=_play_thread, daemon=True)
        thread.start()

class AlertEngine:
    """Coordinate alerts across audio, visual, and WebSocket"""

    def __init__(self):
        self.audio = AudioAlert()
        self.last_alert_level = None

    async def alert(self, threat_level: ThreatLevel, service_name: str, message: str):
        """Trigger an alert"""
        # Play audio
        if threat_level == ThreatLevel.SAFE:
            self.audio.play_safe()
        elif threat_level == ThreatLevel.INFO:
            self.audio.play_info()
        elif threat_level == ThreatLevel.WARNING:
            self.audio.play_warning()
        elif threat_level == ThreatLevel.CRITICAL:
            self.audio.play_critical()
        elif threat_level == ThreatLevel.EMERGENCY:
            self.audio.play_emergency()

        self.last_alert_level = threat_level

        # Broadcast to Web UI via WebSocket
        # (Handled by the router)
        return {
            "threat_level": threat_level.value,
            "service": service_name,
            "message": message
        }
```

## Testing Audio

```python
# tests/test_alerts.py
import pytest
from app.services.alerts import AlertEngine, ThreatLevel

@pytest.mark.asyncio
async def test_alert_audio():
    """Test that alert audio plays without errors"""
    engine = AlertEngine()

    for level in ThreatLevel:
        result = await engine.alert(
            level,
            "com.test.service",
            f"Testing {level.value} alert"
        )
        assert result["threat_level"] == level.value
```

Run the test:

```bash
pytest tests/test_alerts.py -v -s
```

You should hear the audio tones play.

## Visual Indicators (CSS)

The web UI displays color-coded badges for each alert level. See `references/web-ui.md` for the complete HTML/CSS implementation.

```css
.alert-safe {
    background: #10b981;  /* Green */
    color: white;
}

.alert-info {
    background: #3b82f6;  /* Blue */
    color: white;
}

.alert-warning {
    background: #f59e0b;  /* Amber */
    color: white;
}

.alert-critical {
    background: #ef4444;  /* Red */
    color: white;
    font-weight: bold;
}

.alert-emergency {
    background: #dc2626;  /* Dark Red */
    color: white;
    animation: pulse 0.5s infinite;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}
```

## Broadcasting Alerts to Web UI

Alerts are broadcast via WebSocket to all connected clients. The frontend receives them and updates the UI in real-time:

```javascript
// static/js/app.js (snippet)
const ws = new WebSocket('ws://localhost:8000/ws/alerts');

ws.onmessage = (event) => {
    const alert = JSON.parse(event.data);
    console.log('Alert received:', alert);

    // Play audio (backend did this, but we can also play client-side)
    playAlertSound(alert.threat_level);

    // Update visual indicator
    updateThreatBadge(alert.threat_level);

    // Add to alert history
    addAlertToHistory(alert);
};
```

See `references/web-ui.md` for complete WebSocket integration.
