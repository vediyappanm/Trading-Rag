# Haptic Communication System

## Table of Contents
1. [HapticPatterns](#hapticpatterns)
2. [HapticEngine](#hapticengine)
3. [HapticLanguage](#hapticlanguage)
4. [Learn Mode](#learn-mode)

---

## HapticPatterns

Pattern definitions using Android's VibrationEffect API.

```kotlin
package com.tag.guardian.haptic

import android.os.Build
import android.os.VibrationEffect

/**
 * TAG uses five distinct haptic patterns, designed so that a blind user can
 * learn to distinguish them within a few minutes of practice.
 *
 * Design principles:
 * - Each pattern has a unique rhythm (not just different intensity)
 * - Escalation in urgency maps to escalation in speed and intensity
 * - Patterns are short enough to be non-intrusive but long enough to be recognizable
 * - The most critical pattern (EMERGENCY) uses a universally recognized SOS rhythm
 */
object HapticPatterns {

    /**
     * SAFE: Two gentle pulses — "all clear"
     * Pattern: ·  ·
     * Feel: Calm, reassuring, like a heartbeat
     */
    val SAFE = PatternDef(
        name = "safe",
        description = "All services verified",
        timings   = longArrayOf(0, 80, 120, 80),          // pause-vib-pause-vib
        amplitudes = intArrayOf(0, 80, 0, 80),
        totalDurationMs = 280
    )

    /**
     * INFO: Three light taps — "checking something"
     * Pattern: · · ·
     * Feel: Curious, attentive, like a gentle knock
     */
    val INFO = PatternDef(
        name = "info",
        description = "New service detected, verifying",
        timings   = longArrayOf(0, 60, 80, 60, 80, 60),
        amplitudes = intArrayOf(0, 60, 0, 60, 0, 60),
        totalDurationMs = 340
    )

    /**
     * WARNING: Long-short-long — "needs attention"
     * Pattern: ─  ·  ─
     * Feel: Deliberate, like a caution signal
     */
    val WARNING = PatternDef(
        name = "warning",
        description = "Unknown service found",
        timings   = longArrayOf(0, 200, 80, 60, 80, 200),
        amplitudes = intArrayOf(0, 120, 0, 120, 0, 120),
        totalDurationMs = 620
    )

    /**
     * CRITICAL: Three rapid escalating bursts — "danger"
     * Pattern: ·· ··· ····
     * Feel: Urgent, escalating, demands immediate attention
     */
    val CRITICAL = PatternDef(
        name = "critical",
        description = "Suspicious service detected",
        timings   = longArrayOf(
            0, 40, 40, 40,           // burst 1: ··
            120,                      // pause
            40, 30, 40, 30, 40,      // burst 2: ···
            120,                      // pause
            30, 25, 30, 25, 30, 25, 30  // burst 3: ····
        ),
        amplitudes = intArrayOf(
            0, 100, 0, 100,          // burst 1
            0,                        // pause
            140, 0, 140, 0, 140,     // burst 2
            0,                        // pause
            180, 0, 180, 0, 180, 0, 200 // burst 3
        ),
        totalDurationMs = 735
    )

    /**
     * EMERGENCY: SOS pattern (··· ─── ···) — "active threat"
     * Pattern: ··· ─── ···
     * Feel: Unmistakable distress signal, loops until dismissed
     */
    val EMERGENCY = PatternDef(
        name = "emergency",
        description = "Active screen reading by untrusted app",
        timings   = longArrayOf(
            // S: ···
            0, 60, 60, 60, 60, 60,
            // pause
            150,
            // O: ───
            200, 80, 200, 80, 200,
            // pause
            150,
            // S: ···
            60, 60, 60, 60, 60
        ),
        amplitudes = intArrayOf(
            0, 200, 0, 200, 0, 200,
            0,
            255, 0, 255, 0, 255,
            0,
            200, 0, 200, 0, 200
        ),
        totalDurationMs = 1530,
        repeating = true    // Loops until explicitly cancelled
    )

    /** Map threat levels to patterns */
    fun forThreatLevel(level: com.tag.guardian.core.ThreatLevel): PatternDef {
        return when (level) {
            com.tag.guardian.core.ThreatLevel.SAFE -> SAFE
            com.tag.guardian.core.ThreatLevel.LOW -> INFO
            com.tag.guardian.core.ThreatLevel.MEDIUM -> WARNING
            com.tag.guardian.core.ThreatLevel.HIGH -> CRITICAL
            com.tag.guardian.core.ThreatLevel.CRITICAL -> EMERGENCY
        }
    }

    /** All patterns for learn mode iteration */
    val ALL = listOf(SAFE, INFO, WARNING, CRITICAL, EMERGENCY)
}

data class PatternDef(
    val name: String,
    val description: String,
    val timings: LongArray,
    val amplitudes: IntArray,
    val totalDurationMs: Long,
    val repeating: Boolean = false
) {
    /**
     * Convert to Android VibrationEffect.
     * On API 26+, uses createWaveform with amplitude control.
     */
    fun toVibrationEffect(intensityMultiplier: Float = 1.0f): VibrationEffect {
        val scaledAmplitudes = amplitudes.map { amp ->
            (amp * intensityMultiplier).toInt().coerceIn(0, 255)
        }.toIntArray()

        return if (repeating) {
            VibrationEffect.createWaveform(timings, scaledAmplitudes, 0) // 0 = repeat from start
        } else {
            VibrationEffect.createWaveform(timings, scaledAmplitudes, -1) // -1 = no repeat
        }
    }
}
```

---

## HapticEngine

The engine that plays patterns with queuing and priority.

```kotlin
package com.tag.guardian.haptic

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.PriorityQueue
import javax.inject.Inject
import javax.inject.Singleton

data class HapticAlert(
    val pattern: PatternDef,
    val priority: Int,           // Higher = more urgent
    val timestamp: Long = System.currentTimeMillis()
) : Comparable<HapticAlert> {
    override fun compareTo(other: HapticAlert): Int {
        // Higher priority first, then earlier timestamp
        val priorityCompare = other.priority.compareTo(this.priority)
        return if (priorityCompare != 0) priorityCompare
        else this.timestamp.compareTo(other.timestamp)
    }
}

@Singleton
class HapticEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val vibrator: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
        manager.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

    private val alertQueue = PriorityQueue<HapticAlert>()
    private val mutex = Mutex()
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var currentJob: Job? = null
    private var lastPlayedPattern: PatternDef? = null

    /** User preference: 0.0 to 1.0 */
    var intensityMultiplier: Float = 1.0f

    /**
     * Play a pattern immediately, interrupting any lower-priority pattern.
     * Higher-priority patterns preempt lower ones.
     */
    suspend fun play(pattern: PatternDef, priority: Int = 0) {
        mutex.withLock {
            val alert = HapticAlert(pattern, priority)

            // If something is playing, only interrupt if new alert is higher priority
            if (currentJob?.isActive == true) {
                val currentPriority = alertQueue.peek()?.priority ?: -1
                if (priority <= currentPriority) {
                    alertQueue.add(alert)
                    return
                }
                // Preempt current pattern
                vibrator.cancel()
                currentJob?.cancel()
            }

            playInternal(alert)
        }
    }

    private fun playInternal(alert: HapticAlert) {
        lastPlayedPattern = alert.pattern
        val effect = alert.pattern.toVibrationEffect(intensityMultiplier)
        vibrator.vibrate(effect)

        // Schedule next pattern from queue after this one finishes
        currentJob = scope.launch {
            delay(alert.pattern.totalDurationMs + 100) // small buffer
            mutex.withLock {
                val next = alertQueue.poll()
                if (next != null) {
                    playInternal(next)
                }
            }
        }
    }

    /**
     * Replay the last pattern. Useful for double-tap gesture.
     */
    suspend fun replayLast() {
        lastPlayedPattern?.let { play(it) }
    }

    /**
     * Cancel all vibrations and clear the queue.
     */
    fun cancelAll() {
        vibrator.cancel()
        currentJob?.cancel()
        alertQueue.clear()
    }

    /**
     * Play a single short confirmation tap.
     * Used for UI feedback (button presses, toggles).
     */
    fun confirmTap() {
        val effect = VibrationEffect.createOneShot(30, 100)
        vibrator.vibrate(effect)
    }

    /**
     * Check if the device supports amplitude control.
     * Without it, we can only do on/off vibrations (less expressive).
     */
    fun hasAmplitudeControl(): Boolean {
        return vibrator.hasAmplitudeControl()
    }
}
```

---

## HapticLanguage

Maps semantic meanings to patterns for use across the app.

```kotlin
package com.tag.guardian.haptic

/**
 * The haptic language extends beyond threat alerts to cover
 * general app interactions. This makes the app usable purely
 * through touch for users who prefer minimal audio.
 */
object HapticLanguage {

    // Threat alerts (primary use)
    val THREAT_SAFE = HapticPatterns.SAFE
    val THREAT_INFO = HapticPatterns.INFO
    val THREAT_WARNING = HapticPatterns.WARNING
    val THREAT_CRITICAL = HapticPatterns.CRITICAL
    val THREAT_EMERGENCY = HapticPatterns.EMERGENCY

    // Navigation feedback
    val NAV_CONFIRM = PatternDef(
        name = "nav_confirm",
        description = "Action confirmed",
        timings = longArrayOf(0, 30),
        amplitudes = intArrayOf(0, 100),
        totalDurationMs = 30
    )

    val NAV_ERROR = PatternDef(
        name = "nav_error",
        description = "Action failed",
        timings = longArrayOf(0, 100, 50, 100),
        amplitudes = intArrayOf(0, 180, 0, 180),
        totalDurationMs = 250
    )

    val NAV_BOUNDARY = PatternDef(
        name = "nav_boundary",
        description = "End of list or screen",
        timings = longArrayOf(0, 50, 30, 50),
        amplitudes = intArrayOf(0, 60, 0, 60),
        totalDurationMs = 130
    )

    // Mode switching
    val MODE_HAPTIC_ONLY = PatternDef(
        name = "mode_haptic",
        description = "Switched to haptic-only mode",
        timings = longArrayOf(0, 100, 200, 100),
        amplitudes = intArrayOf(0, 150, 0, 80),
        totalDurationMs = 400
    )

    val MODE_VOICE_HAPTIC = PatternDef(
        name = "mode_voice",
        description = "Switched to voice + haptic mode",
        timings = longArrayOf(0, 80, 100, 150),
        amplitudes = intArrayOf(0, 80, 0, 150),
        totalDurationMs = 330
    )

    // Sync status
    val SYNC_COMPLETE = PatternDef(
        name = "sync_complete",
        description = "Whitelist sync completed",
        timings = longArrayOf(0, 40, 60, 40, 60, 80),
        amplitudes = intArrayOf(0, 60, 0, 60, 0, 100),
        totalDurationMs = 280
    )
}
```

---

## Learn Mode

During onboarding, each pattern plays paired with a TTS explanation. This is implemented in the OnboardingScreen (see ui-accessibility.md), but the sequencing logic lives here:

```kotlin
package com.tag.guardian.haptic

import android.content.Context
import android.speech.tts.TextToSpeech
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HapticLearnMode @Inject constructor(
    @ApplicationContext private val context: Context,
    private val hapticEngine: HapticEngine
) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    fun initialize() {
        tts = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
        }
    }

    /**
     * Teach a single pattern:
     * 1. Speak the pattern name and meaning
     * 2. Wait for speech to finish
     * 3. Play the haptic pattern
     * 4. Pause for the user to absorb
     */
    suspend fun teachPattern(pattern: PatternDef) {
        if (!ttsReady) return

        val explanation = when (pattern.name) {
            "safe" -> "Safe pattern. Two gentle pulses. This means all your accessibility services are verified and trustworthy. You'll feel it now."
            "info" -> "Information pattern. Three light taps. This means a new service was detected and is being checked. You'll feel it now."
            "warning" -> "Warning pattern. Long, short, long. This means an unknown service was found that needs your review. You'll feel it now."
            "critical" -> "Critical alert. Three rapid escalating bursts. This means a suspicious service was detected that may be malware. You'll feel it now."
            "emergency" -> "Emergency alert. An SOS pattern that repeats. This means an untrusted app is actively reading your screen. You'll feel it now."
            else -> "${pattern.description}. You'll feel it now."
        }

        // Speak the explanation
        tts?.speak(explanation, TextToSpeech.QUEUE_FLUSH, null, "learn_${pattern.name}")

        // Wait for speech (approximate — Android TTS doesn't have great completion callbacks)
        delay(explanation.length * 55L) // ~55ms per character at normal speed

        // Play the pattern
        hapticEngine.play(pattern)

        // Let the user feel it fully before moving on
        delay(pattern.totalDurationMs + 1500)
    }

    /**
     * Run through all threat patterns in order of severity.
     */
    suspend fun teachAllPatterns() {
        for (pattern in HapticPatterns.ALL) {
            teachPattern(pattern)
            delay(500) // Brief gap between patterns
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
```
