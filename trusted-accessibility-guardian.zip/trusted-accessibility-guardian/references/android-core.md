# Android Core — Accessibility Monitoring Implementation

## Table of Contents
1. [AccessibilityMonitor](#accessibilitymonitor)
2. [ServiceVerifier](#serviceverifier)
3. [ThreatAssessment](#threatassessment)
4. [MonitoringService](#monitoringservice)
5. [BootReceiver](#bootreceiver)

---

## AccessibilityMonitor

The core scanner that reads currently enabled accessibility services from the system.

```kotlin
package com.tag.guardian.core

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.pm.PackageManager
import android.view.accessibility.AccessibilityManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

data class DetectedService(
    val packageName: String,
    val serviceName: String,
    val appLabel: String,
    val description: String?,
    val feedbackType: Int,
    val capabilities: Int,
    val signingCertHash: String?
)

@Singleton
class AccessibilityMonitor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val accessibilityManager =
        context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager

    private val _activeServices = MutableStateFlow<List<DetectedService>>(emptyList())
    val activeServices: StateFlow<List<DetectedService>> = _activeServices

    /**
     * Scan all currently enabled accessibility services.
     *
     * Uses getEnabledAccessibilityServiceList() which returns services the user
     * has explicitly enabled in Settings > Accessibility. This does NOT require
     * TAG itself to be an accessibility service.
     *
     * FEEDBACK_ALL_MASK captures all feedback types: spoken, haptic, audible,
     * visual, generic, and braille.
     */
    fun scanServices(): List<DetectedService> {
        val enabledServices = accessibilityManager.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )

        val detected = enabledServices.map { info ->
            val resolveInfo = info.resolveInfo
            val packageName = resolveInfo.serviceInfo.packageName
            val serviceName = resolveInfo.serviceInfo.name

            DetectedService(
                packageName = packageName,
                serviceName = serviceName,
                appLabel = resolveInfo.loadLabel(context.packageManager).toString(),
                description = info.description?.toString(),
                feedbackType = info.feedbackType,
                capabilities = info.capabilities,
                signingCertHash = getSigningCertHash(packageName)
            )
        }

        _activeServices.value = detected
        return detected
    }

    /**
     * Get the SHA-256 hash of the app's signing certificate.
     * This is how we verify a package is the real deal and not a repackaged
     * malware version pretending to be TalkBack.
     */
    private fun getSigningCertHash(packageName: String): String? {
        return try {
            val packageInfo = if (android.os.Build.VERSION.SDK_INT >= 28) {
                context.packageManager.getPackageInfo(
                    packageName,
                    PackageManager.GET_SIGNING_CERTIFICATES
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(
                    packageName,
                    PackageManager.GET_SIGNATURES
                )
            }

            val signatures = if (android.os.Build.VERSION.SDK_INT >= 28) {
                packageInfo.signingInfo?.apkContentsSigners
            } else {
                @Suppress("DEPRECATION")
                packageInfo.signatures
            }

            signatures?.firstOrNull()?.let { sig ->
                val digest = java.security.MessageDigest.getInstance("SHA-256")
                val hash = digest.digest(sig.toByteArray())
                hash.joinToString(":") { "%02X".format(it) }
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Check if accessibility is enabled at all on the device.
     */
    fun isAccessibilityEnabled(): Boolean = accessibilityManager.isEnabled

    /**
     * Check if a specific service is currently running.
     */
    fun isServiceActive(packageName: String): Boolean {
        return _activeServices.value.any { it.packageName == packageName }
    }
}
```

---

## ServiceVerifier

Checks detected services against the whitelist and produces a verification result.

```kotlin
package com.tag.guardian.core

import com.tag.guardian.data.WhitelistRepository
import com.tag.guardian.data.WhitelistEntry
import javax.inject.Inject
import javax.inject.Singleton

enum class VerificationStatus {
    VERIFIED,           // In whitelist, cert matches
    CERT_MISMATCH,      // In whitelist, but signing cert doesn't match (repackaged!)
    UNKNOWN,            // Not in whitelist
    USER_APPROVED       // Not in global whitelist, but user manually approved
}

data class VerifiedService(
    val service: DetectedService,
    val status: VerificationStatus,
    val whitelistEntry: WhitelistEntry?,
    val riskScore: Int   // 0 = safe, 100 = definitely malicious
)

@Singleton
class ServiceVerifier @Inject constructor(
    private val whitelistRepo: WhitelistRepository
) {
    /**
     * Verify a single detected service against the whitelist.
     *
     * The verification logic:
     * 1. Look up package name in whitelist
     * 2. If found, compare signing certificate hash
     * 3. If cert matches → VERIFIED (risk 0)
     * 4. If cert doesn't match → CERT_MISMATCH (risk 95 — very likely malware)
     * 5. If not in whitelist, check user-approved list
     * 6. If user-approved → USER_APPROVED (risk 10)
     * 7. Otherwise → UNKNOWN (risk 60 — needs investigation)
     */
    suspend fun verify(service: DetectedService): VerifiedService {
        val whitelistEntry = whitelistRepo.findByPackage(service.packageName)

        if (whitelistEntry != null) {
            // Package is in whitelist — verify the signing certificate
            if (service.signingCertHash != null &&
                whitelistEntry.signingCertificateHash != null &&
                service.signingCertHash == whitelistEntry.signingCertificateHash
            ) {
                return VerifiedService(service, VerificationStatus.VERIFIED, whitelistEntry, 0)
            }

            // Package name matches but cert doesn't — this is a red flag
            // Someone repackaged a known app with different signing keys
            if (service.signingCertHash != null &&
                whitelistEntry.signingCertificateHash != null &&
                service.signingCertHash != whitelistEntry.signingCertificateHash
            ) {
                return VerifiedService(service, VerificationStatus.CERT_MISMATCH, whitelistEntry, 95)
            }

            // Cert info unavailable — trust the whitelist but note uncertainty
            return VerifiedService(service, VerificationStatus.VERIFIED, whitelistEntry, 5)
        }

        // Not in global whitelist — check if user manually approved
        if (whitelistRepo.isUserApproved(service.packageName)) {
            return VerifiedService(service, VerificationStatus.USER_APPROVED, null, 10)
        }

        // Completely unknown service
        return VerifiedService(service, VerificationStatus.UNKNOWN, null, 60)
    }

    /**
     * Verify all currently detected services.
     */
    suspend fun verifyAll(services: List<DetectedService>): List<VerifiedService> {
        return services.map { verify(it) }
    }
}
```

---

## ThreatAssessment

Aggregate risk scoring across all active services.

```kotlin
package com.tag.guardian.core

import javax.inject.Inject
import javax.inject.Singleton

enum class ThreatLevel {
    SAFE,       // All services verified, risk 0
    LOW,        // Minor unknowns, user-approved services
    MEDIUM,     // Unknown services present
    HIGH,       // Cert mismatch or multiple unknowns
    CRITICAL    // Active screen reading by unverified service
}

data class ThreatReport(
    val level: ThreatLevel,
    val overallRisk: Int,
    val verifiedServices: List<VerifiedService>,
    val threats: List<VerifiedService>,      // Non-VERIFIED services
    val summary: String
)

@Singleton
class ThreatAssessment @Inject constructor() {

    fun assess(verifiedServices: List<VerifiedService>): ThreatReport {
        val threats = verifiedServices.filter {
            it.status != VerificationStatus.VERIFIED
        }

        val maxRisk = verifiedServices.maxOfOrNull { it.riskScore } ?: 0

        // Check for especially dangerous capabilities
        val hasScreenReader = threats.any { service ->
            service.service.capabilities and
                android.accessibilityservice.AccessibilityServiceInfo.CAPABILITY_CAN_RETRIEVE_WINDOW_CONTENT != 0
        }

        val level = when {
            threats.isEmpty() -> ThreatLevel.SAFE
            maxRisk >= 90 -> ThreatLevel.CRITICAL
            hasScreenReader && maxRisk >= 50 -> ThreatLevel.HIGH
            maxRisk >= 50 -> ThreatLevel.MEDIUM
            else -> ThreatLevel.LOW
        }

        // Adjust overall risk if an unknown service can read screen contents
        val overallRisk = if (hasScreenReader && maxRisk < 80) maxRisk + 20 else maxRisk

        val summary = buildSummary(level, verifiedServices.size, threats, hasScreenReader)

        return ThreatReport(level, overallRisk.coerceAtMost(100), verifiedServices, threats, summary)
    }

    private fun buildSummary(
        level: ThreatLevel,
        totalCount: Int,
        threats: List<VerifiedService>,
        hasScreenReader: Boolean
    ): String = when (level) {
        ThreatLevel.SAFE ->
            "$totalCount accessibility services active, all verified."
        ThreatLevel.LOW ->
            "$totalCount services active. ${threats.size} user-approved but not globally verified."
        ThreatLevel.MEDIUM ->
            "${threats.size} unknown service(s) detected. Review recommended."
        ThreatLevel.HIGH -> {
            val screenReaderWarning = if (hasScreenReader)
                " An unverified service can read your screen contents." else ""
            "${threats.size} suspicious service(s) detected.$screenReaderWarning"
        }
        ThreatLevel.CRITICAL ->
            "CRITICAL: ${threats.size} potentially malicious service(s) detected with screen reading capability."
    }
}
```

---

## MonitoringService

Foreground service that runs continuous scans in the background.

```kotlin
package com.tag.guardian.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.tag.guardian.MainActivity
import com.tag.guardian.R
import com.tag.guardian.alert.AlertCoordinator
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class MonitoringService : Service() {

    @Inject lateinit var monitor: AccessibilityMonitor
    @Inject lateinit var verifier: ServiceVerifier
    @Inject lateinit var assessment: ThreatAssessment
    @Inject lateinit var alertCoordinator: AlertCoordinator

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var scanIntervalMs: Long = 60_000L  // Default: scan every 60 seconds

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Monitoring active"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.getLongExtra("scan_interval_ms", 60_000L)?.let {
            scanIntervalMs = it
        }

        serviceScope.launch {
            while (isActive) {
                performScan()
                delay(scanIntervalMs)
            }
        }

        return START_STICKY  // Restart if killed by system
    }

    private suspend fun performScan() {
        val services = monitor.scanServices()
        val verified = verifier.verifyAll(services)
        val report = assessment.assess(verified)

        // Update notification with current status
        updateNotification(report.summary)

        // Trigger alerts for non-safe threat levels
        if (report.level != ThreatLevel.SAFE) {
            alertCoordinator.handleThreat(report)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "TAG Guardian Monitoring",
                NotificationManager.IMPORTANCE_LOW  // Low = no sound, shows in status bar
            ).apply {
                description = "Ongoing accessibility service monitoring"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TAG Guardian")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_shield)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "tag_monitoring"
        const val NOTIFICATION_ID = 1001
    }
}
```

---

## BootReceiver

Restarts monitoring after device reboot.

```kotlin
package com.tag.guardian.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val serviceIntent = Intent(context, MonitoringService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}
```

---

## Data Layer — WhitelistRepository

```kotlin
package com.tag.guardian.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "whitelist")
data class WhitelistEntry(
    @PrimaryKey val packageName: String,
    val appName: String,
    val developer: String?,
    val signingCertificateHash: String?,
    val category: String,          // screen_reader, switch_access, voice_control, other
    val verified: Boolean,
    val verificationSource: String, // play_store, manual, community
    val lastVerified: Long,         // epoch millis
    val riskScore: Int
)

@Entity(tableName = "user_approved")
data class UserApprovedService(
    @PrimaryKey val packageName: String,
    val approvedAt: Long,
    val reason: String?
)

@Dao
interface WhitelistDao {
    @Query("SELECT * FROM whitelist WHERE packageName = :pkg")
    suspend fun findByPackage(pkg: String): WhitelistEntry?

    @Query("SELECT * FROM whitelist")
    fun getAllEntries(): Flow<List<WhitelistEntry>>

    @Upsert
    suspend fun upsertAll(entries: List<WhitelistEntry>)

    @Query("SELECT EXISTS(SELECT 1 FROM user_approved WHERE packageName = :pkg)")
    suspend fun isUserApproved(pkg: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun approveService(entry: UserApprovedService)

    @Query("DELETE FROM user_approved WHERE packageName = :pkg")
    suspend fun revokeApproval(pkg: String)
}

@Database(
    entities = [WhitelistEntry::class, UserApprovedService::class],
    version = 1,
    exportSchema = false
)
abstract class TagDatabase : RoomDatabase() {
    abstract fun whitelistDao(): WhitelistDao
}
```

```kotlin
package com.tag.guardian.data

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WhitelistRepository @Inject constructor(
    private val dao: WhitelistDao,
    private val apiService: com.tag.guardian.network.TagApiService
) {
    suspend fun findByPackage(pkg: String): WhitelistEntry? = dao.findByPackage(pkg)

    suspend fun isUserApproved(pkg: String): Boolean = dao.isUserApproved(pkg)

    fun getAllEntries() = dao.getAllEntries()

    suspend fun approveService(pkg: String, reason: String?) {
        dao.approveService(
            UserApprovedService(pkg, System.currentTimeMillis(), reason)
        )
    }

    suspend fun revokeApproval(pkg: String) = dao.revokeApproval(pkg)

    /**
     * Sync whitelist from backend.
     * Merges remote entries with local — remote is authoritative for verified entries.
     */
    suspend fun syncFromRemote(): Result<Int> {
        return try {
            val response = apiService.getWhitelist()
            if (response.isSuccessful) {
                val entries = response.body() ?: emptyList()
                dao.upsertAll(entries)
                Result.success(entries.size)
            } else {
                Result.failure(Exception("Sync failed: ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        /**
         * Default whitelist — well-known accessibility services that are
         * pre-verified. These are baked into the app so it works offline
         * from first launch.
         */
        val DEFAULT_WHITELIST = listOf(
            WhitelistEntry(
                packageName = "com.google.android.marvin.talkback",
                appName = "TalkBack",
                developer = "Google LLC",
                signingCertificateHash = null, // Populated at build time
                category = "screen_reader",
                verified = true,
                verificationSource = "built_in",
                lastVerified = System.currentTimeMillis(),
                riskScore = 0
            ),
            WhitelistEntry(
                packageName = "com.samsung.accessibility.talkback",
                appName = "Voice Assistant (Samsung)",
                developer = "Samsung Electronics",
                signingCertificateHash = null,
                category = "screen_reader",
                verified = true,
                verificationSource = "built_in",
                lastVerified = System.currentTimeMillis(),
                riskScore = 0
            ),
            WhitelistEntry(
                packageName = "com.google.android.apps.accessibility.voiceaccess",
                appName = "Voice Access",
                developer = "Google LLC",
                signingCertificateHash = null,
                category = "voice_control",
                verified = true,
                verificationSource = "built_in",
                lastVerified = System.currentTimeMillis(),
                riskScore = 0
            ),
            WhitelistEntry(
                packageName = "com.android.switchaccess",
                appName = "Switch Access",
                developer = "Google LLC",
                signingCertificateHash = null,
                category = "switch_access",
                verified = true,
                verificationSource = "built_in",
                lastVerified = System.currentTimeMillis(),
                riskScore = 0
            )
        )
    }
}
```
