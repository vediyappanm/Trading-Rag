# ML Pipeline — Audio Environment Classification

## Model Overview

A TensorFlow Lite audio classifier that detects whether the user is in a **public** or **private** environment based on 1-second audio windows.

### Architecture

```
Input: 1-second audio (44.1 kHz) → Mel Spectrogram (64 bands, 44 frames)
  ↓
Conv2D(32, 3x3, padding='same') → BatchNormalization → ReLU → MaxPool(2x2)
  ↓
Conv2D(64, 3x3, padding='same') → BatchNormalization → ReLU → MaxPool(2x2)
  ↓
Conv2D(128, 3x3, padding='same') → BatchNormalization → ReLU → GlobalAveragePooling
  ↓
Dense(64) → Dropout(0.3) → Dense(2) → Softmax
  ↓
Output: [public_prob, private_prob]
```

**Model size**: < 2MB (TFLite), suitable for on-device inference.

## Download Pre-Trained Model

The model is automatically downloaded and cached:

```bash
python -c "from models.audio_classifier import NoiseClassifier; NoiseClassifier.download_model()"
```

This downloads `noise_classifier.tflite` (~100MB) from a model registry and caches it locally.

## On-Device Inference (models/audio_classifier.py)

```python
import tensorflow as tf
import librosa
import numpy as np
import sounddevice as sd
import threading
import os
from pathlib import Path

class NoiseClassifier:
    def __init__(self, model_path: str = "models/noise_classifier.tflite"):
        self.model_path = model_path
        self.interpreter = tf.lite.Interpreter(model_path=model_path)
        self.interpreter.allocate_tensors()

        # Get input/output tensor details
        self.input_details = self.interpreter.get_input_details()[0]
        self.output_details = self.interpreter.get_output_details()[0]

        # Audio capture settings
        self.sample_rate = 44100
        self.duration = 1.0  # 1-second windows
        self.n_mels = 64

    @staticmethod
    def download_model():
        """Download and cache the pre-trained model"""
        cache_dir = Path("models/cache")
        cache_dir.mkdir(parents=True, exist_ok=True)

        model_path = cache_dir / "noise_classifier.tflite"
        if model_path.exists():
            return str(model_path)

        # Download from model registry (placeholder URL)
        import urllib.request
        url = "https://models.example.com/noise_classifier.tflite"
        print(f"Downloading model... (this may take a few minutes)")
        urllib.request.urlretrieve(url, model_path)
        return str(model_path)

    def preprocess_audio(self, audio: np.ndarray) -> np.ndarray:
        """
        Convert raw audio to mel spectrogram.

        Args:
            audio: Raw audio samples (44.1 kHz)

        Returns:
            Mel spectrogram (64, 44) normalized to [-1, 1]
        """
        # Compute mel spectrogram
        mel_spec = librosa.feature.melspectrogram(
            y=audio,
            sr=self.sample_rate,
            n_mels=self.n_mels,
            n_fft=2048,
            hop_length=512
        )

        # Convert to dB scale
        mel_spec_db = librosa.power_to_db(mel_spec, ref=np.max)

        # Normalize to [-1, 1]
        mel_spec_normalized = (mel_spec_db - mel_spec_db.min()) / (mel_spec_db.max() - mel_spec_db.min() + 1e-5)
        mel_spec_normalized = 2 * mel_spec_normalized - 1

        return mel_spec_normalized.astype(np.float32)

    def classify(self, audio: np.ndarray) -> tuple:
        """
        Classify audio as public or private.

        Args:
            audio: Raw audio samples

        Returns:
            (public_probability, private_probability)
        """
        # Preprocess
        mel_spec = self.preprocess_audio(audio)

        # Add batch dimension: (64, 44) → (1, 64, 44, 1)
        input_tensor = np.expand_dims(mel_spec, axis=(0, -1))

        # Run inference
        self.interpreter.set_tensor(self.input_details["index"], input_tensor)
        self.interpreter.invoke()

        # Get output
        output = self.interpreter.get_tensor(self.output_details["index"])[0]
        public_prob, private_prob = output

        return float(public_prob), float(private_prob)

    def classify_from_mic(self) -> tuple:
        """
        Record 1 second from the mic and classify.

        Returns:
            (public_probability, private_probability)
        """
        print("Recording...")
        audio = sd.rec(
            int(self.sample_rate * self.duration),
            samplerate=self.sample_rate,
            channels=1,
            dtype='float32'
        )
        sd.wait()
        audio = audio.squeeze()

        return self.classify(audio)

    def classify_latest(self) -> tuple:
        """
        Classify the latest audio window from a background recording.

        (Simplified: in production, a background thread would continuously
        capture audio and this would return the latest window.)
        """
        return self.classify_from_mic()

# Global instance for the API
_classifier = None

def get_classifier():
    global _classifier
    if _classifier is None:
        model_path = NoiseClassifier.download_model()
        _classifier = NoiseClassifier(model_path)
    return _classifier
```

## Training the Model (Optional)

If you want to retrain on your own data:

```bash
# Install training dependencies
pip install tensorflow scikit-learn matplotlib

# Run the training script
python models/train_classifier.py \
    --esc50-path ./data/ESC-50 \
    --urbansound-path ./data/UrbanSound8K \
    --output models/noise_classifier.tflite \
    --epochs 50
```

### Training Script (models/train_classifier.py)

```python
"""
Train a binary audio classifier: public vs private environment.

Data sources:
- ESC-50: Environmental sound classification dataset
- UrbanSound8K: Urban sound tagging dataset

This script labels samples and trains a TensorFlow model,
then converts to TFLite for on-device inference.
"""

import tensorflow as tf
import librosa
import numpy as np
from pathlib import Path
import argparse

# Class labels
LABEL_MAPPING = {
    "public": 0,
    "private": 1
}

PUBLIC_KEYWORDS = [
    "traffic", "car", "street", "crowd", "people",
    "train", "bus", "restaurant", "park", "siren"
]

PRIVATE_KEYWORDS = [
    "silence", "quiet", "room", "office", "home",
    "breathing", "typing", "keyboard", "fridge", "refrigerator"
]

def label_audio_file(filename: str) -> int:
    """Heuristically label an audio file as public or private"""
    name_lower = filename.lower()

    if any(keyword in name_lower for keyword in PUBLIC_KEYWORDS):
        return LABEL_MAPPING["public"]
    elif any(keyword in name_lower for keyword in PRIVATE_KEYWORDS):
        return LABEL_MAPPING["private"]
    else:
        # Default: private (safer assumption)
        return LABEL_MAPPING["private"]

def build_model(input_shape=(64, 44, 1)):
    """Build the audio classifier"""
    model = tf.keras.Sequential([
        tf.keras.layers.Conv2D(32, (3, 3), padding='same', input_shape=input_shape,
                               activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D((2, 2)),

        tf.keras.layers.Conv2D(64, (3, 3), padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D((2, 2)),

        tf.keras.layers.Conv2D(128, (3, 3), padding='same', activation='relu'),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.GlobalAveragePooling2D(),

        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(2, activation='softmax')
    ])

    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    return model

def train(esc50_path: str, urbansound_path: str, output: str, epochs: int):
    """Train the model on ESC-50 and UrbanSound8K"""
    # Load and preprocess data
    # (Placeholder: real implementation loads from ESC-50 and UrbanSound8K)

    # Build and train
    model = build_model()
    # X_train, y_train = load_training_data(...)
    # model.fit(X_train, y_train, epochs=epochs, validation_split=0.2)

    # Convert to TFLite
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    tflite_model = converter.convert()

    # Save
    with open(output, 'wb') as f:
        f.write(tflite_model)

    print(f"Model saved to {output}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--esc50-path", required=True)
    parser.add_argument("--urbansound-path", required=True)
    parser.add_argument("--output", default="models/noise_classifier.tflite")
    parser.add_argument("--epochs", type=int, default=50)

    args = parser.parse_args()
    train(args.esc50_path, args.urbansound_path, args.output, args.epochs)
```

## Integration with FastAPI

The ML classifier is exposed via the `/api/ml/environment` endpoint:

```python
# app/routers/ml.py
from fastapi import APIRouter
from models.audio_classifier import get_classifier
from app.models import EnvironmentResponse

router = APIRouter()

@router.get("/ml/environment", response_model=EnvironmentResponse)
async def get_environment():
    """Get current environment classification"""
    classifier = get_classifier()
    public_prob, private_prob = classifier.classify_latest()

    classification = "public" if public_prob > private_prob else "private"
    confidence = max(public_prob, private_prob)

    return EnvironmentResponse(
        public_probability=float(public_prob),
        private_probability=float(private_prob),
        classification=classification,
        confidence=float(confidence)
    )
```

## Testing the Classifier

```bash
# Test with mic input
python -c "
from models.audio_classifier import NoiseClassifier
classifier = NoiseClassifier()
public_prob, private_prob = classifier.classify_from_mic()
print(f'Public: {public_prob:.2%}, Private: {private_prob:.2%}')
"
```

Speak loudly (public) vs. whisper (private) to see the classification change.
