# Process Monitoring Implementation

## Simulated Services (Prototype)

For the laptop prototype, we simulate services without needing Android. Here's `app/services/process_monitor.py`:

```python
from dataclasses import dataclass
from typing import List
from datetime import datetime
from sqlalchemy.orm import Session
from database import Service

@dataclass
class MockService:
    name: str
    package_name: str
    category: str  # screen_reader, voice_control, switch_access, unknown
    is_verified: bool
    risk_score: int

# Mock services for testing
MOCK_SERVICES = [
    MockService(
        name="TalkBack",
        package_name="com.google.android.marvin.talkback",
        category="screen_reader",
        is_verified=True,
        risk_score=0
    ),
    MockService(
        name="Voice Access",
        package_name="com.google.android.apps.accessibility.voiceaccess",
        category="voice_control",
        is_verified=True,
        risk_score=0
    ),
    MockService(
        name="Samsung Voice Assistant",
        package_name="com.samsung.accessibility.talkback",
        category="screen_reader",
        is_verified=True,
        risk_score=0
    ),
]

# Simulated "suspicious" service (can be toggled on/off for testing)
SUSPICIOUS_SERVICES = [
    MockService(
        name="Screen Monitor",
        package_name="com.screenmonitor.service",
        category="unknown",
        is_verified=False,
        risk_score=75
    ),
    MockService(
        name="Battery Optimizer",
        package_name="com.fakebatteryoptimizer",
        category="unknown",
        is_verified=False,
        risk_score=85
    ),
]

# Toggle this to test suspicious service detection
INCLUDE_SUSPICIOUS = True

class ProcessMonitor:
    def __init__(self, db: Session):
        self.db = db

    def scan(self) -> List[Service]:
        """
        Scan for currently active accessibility services.

        In a real implementation, this would:
        1. On Android: call AccessibilityManager.getEnabledAccessibilityServiceList()
        2. On Windows/macOS: parse running processes or system logs

        For the prototype, we return mock services.
        """
        services = []

        # Add baseline services
        for mock in MOCK_SERVICES:
            service = Service(
                package_name=mock.package_name,
                app_name=mock.name,
                category=mock.category,
                is_verified=mock.is_verified,
                risk_score=mock.risk_score,
                last_seen=datetime.utcnow()
            )
            services.append(service)

        # Optionally add suspicious services
        if INCLUDE_SUSPICIOUS:
            for mock in SUSPICIOUS_SERVICES:
                service = Service(
                    package_name=mock.package_name,
                    app_name=mock.name,
                    category=mock.category,
                    is_verified=mock.is_verified,
                    risk_score=mock.risk_score,
                    last_seen=datetime.utcnow()
                )
                services.append(service)

        return services

    def toggle_suspicious(self):
        """For testing: toggle suspicious services on/off"""
        global INCLUDE_SUSPICIOUS
        INCLUDE_SUSPICIOUS = not INCLUDE_SUSPICIOUS
```

## Adding Real Process Enumeration (Optional)

For Windows, you can use the `psutil` library to enumerate actual processes:

```bash
pip install psutil
```

Then replace the mock implementation:

```python
import psutil
from datetime import datetime

class RealProcessMonitor:
    def __init__(self, db: Session):
        self.db = db
        self.known_accessibility_packages = {
            "com.google.android.marvin.talkback",
            "com.google.android.apps.accessibility.voiceaccess",
            "com.samsung.accessibility",
            # ... add more known packages
        }

    def scan(self) -> List[Service]:
        """
        Scan running processes and look for accessibility-related ones.

        This is a simplified heuristic that looks for process names containing
        accessibility keywords.
        """
        services = []

        for proc in psutil.process_iter(['pid', 'name', 'exe']):
            try:
                if any(keyword in proc.info['name'].lower() for keyword in
                       ['access', 'talkback', 'voice', 'speech', 'reader']):

                    service = Service(
                        package_name=proc.info['name'],
                        app_name=proc.info['name'],
                        category="unknown",  # Would need additional logic to classify
                        is_verified=False,
                        risk_score=50,
                        last_seen=datetime.utcnow()
                    )
                    services.append(service)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        return services
```

## Testing Process Monitor

Create `tests/test_process_monitor.py`:

```python
import pytest
from app.services.process_monitor import ProcessMonitor
from database import SessionLocal, init_db

@pytest.fixture
def db():
    init_db()
    return SessionLocal()

def test_scan_returns_services(db):
    monitor = ProcessMonitor(db)
    services = monitor.scan()

    assert len(services) > 0
    assert any(s.package_name == "com.google.android.marvin.talkback" for s in services)

def test_verified_services_have_zero_risk(db):
    monitor = ProcessMonitor(db)
    services = monitor.scan()

    for service in services:
        if service.is_verified:
            assert service.risk_score == 0

def test_toggle_suspicious_changes_count(db):
    monitor = ProcessMonitor(db)

    services_before = len(monitor.scan())
    monitor.toggle_suspicious()
    services_after = len(monitor.scan())

    assert services_before != services_after
```

Run tests:

```bash
pytest tests/test_process_monitor.py -v
```
