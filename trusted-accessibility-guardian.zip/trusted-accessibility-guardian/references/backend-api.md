# Backend API Implementation

## FastAPI Setup (main.py)

```python
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import uvicorn
from contextlib import asynccontextmanager
import asyncio

from database import init_db, SessionLocal
from app.routers import services, scanning, alerts, ml
from app.services.background_scanner import start_background_scanner

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    init_db()
    asyncio.create_task(start_background_scanner())
    yield
    # Shutdown (cleanup here if needed)

app = FastAPI(title="TAG Guardian", version="0.1.0", lifespan=lifespan)

# Include routers
app.include_router(services.router, prefix="/api", tags=["services"])
app.include_router(scanning.router, prefix="/api", tags=["scanning"])
app.include_router(alerts.router, prefix="/api", tags=["alerts"])
app.include_router(ml.router, prefix="/api", tags=["ml"])

# Serve static files (HTML, CSS, JS)
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def root():
    """Serve the main dashboard"""
    return FileResponse("static/index.html")

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {"status": "ok"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
```

## Database Setup (database.py)

```python
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./tag.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Models
class Service(Base):
    __tablename__ = "services"
    id = Column(Integer, primary_key=True, index=True)
    package_name = Column(String, unique=True, index=True)
    app_name = Column(String)
    category = Column(String)  # screen_reader, voice_control, unknown
    is_verified = Column(Boolean, default=False)
    risk_score = Column(Integer, default=0)  # 0-100
    last_seen = Column(DateTime, default=datetime.utcnow)

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True, index=True)
    service_id = Column(Integer)
    threat_level = Column(String)  # safe, info, warning, critical, emergency
    message = Column(String)
    acknowledged = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class WhitelistEntry(Base):
    __tablename__ = "whitelist"
    id = Column(Integer, primary_key=True, index=True)
    package_name = Column(String, unique=True, index=True)
    app_name = Column(String)
    developer = Column(String)
    category = Column(String)  # screen_reader, voice_control, switch_access
    verified = Column(Boolean, default=True)

def init_db():
    Base.metadata.create_all(bind=engine)
    # Seed default whitelist if empty
    from sqlalchemy.orm import Session
    db = Session(bind=engine)
    if db.query(WhitelistEntry).count() == 0:
        defaults = [
            WhitelistEntry(package_name="com.google.android.marvin.talkback", app_name="TalkBack", developer="Google", category="screen_reader"),
            WhitelistEntry(package_name="com.samsung.accessibility.talkback", app_name="Samsung Voice Assistant", developer="Samsung", category="screen_reader"),
            WhitelistEntry(package_name="com.google.android.apps.accessibility.voiceaccess", app_name="Voice Access", developer="Google", category="voice_control"),
            WhitelistEntry(package_name="com.android.switchaccess", app_name="Switch Access", developer="Google", category="switch_access"),
        ]
        db.add_all(defaults)
        db.commit()
    db.close()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

## Pydantic Models (app/models.py)

```python
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class ServiceResponse(BaseModel):
    id: int
    package_name: str
    app_name: str
    category: str
    is_verified: bool
    risk_score: int
    last_seen: datetime

    class Config:
        from_attributes = True

class AlertResponse(BaseModel):
    id: int
    service_id: int
    threat_level: str
    message: str
    acknowledged: bool
    created_at: datetime

    class Config:
        from_attributes = True

class ScanResult(BaseModel):
    total_services: int
    verified_services: int
    unknown_services: int
    threat_level: str
    risk_score: int
    timestamp: datetime

class EnvironmentResponse(BaseModel):
    public_probability: float
    private_probability: float
    classification: str  # "public" or "private"
    confidence: float
```

## Service Monitoring Router (app/routers/services.py)

```python
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db, Service
from app.models import ServiceResponse
from typing import List

router = APIRouter()

@router.get("/services", response_model=List[ServiceResponse])
async def get_services(db: Session = Depends(get_db)):
    """Get all currently detected services"""
    services = db.query(Service).all()
    return services

@router.get("/services/{service_id}", response_model=ServiceResponse)
async def get_service(service_id: int, db: Session = Depends(get_db)):
    """Get details for a specific service"""
    service = db.query(Service).filter(Service.id == service_id).first()
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    return service
```

## Scanning Router (app/routers/scanning.py)

```python
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
from app.services.process_monitor import ProcessMonitor
from app.services.whitelist import WhitelistChecker
from app.services.threat_assessment import ThreatAssessment
from app.models import ScanResult
from datetime import datetime

router = APIRouter()

@router.post("/scan", response_model=ScanResult)
async def trigger_scan(db: Session = Depends(get_db)):
    """Trigger an immediate scan of all services"""
    monitor = ProcessMonitor(db)
    whitelist = WhitelistChecker(db)
    assessment = ThreatAssessment()

    # Detect current services
    services = monitor.scan()

    # Verify against whitelist
    verified_count = 0
    unknown_count = 0
    max_risk = 0

    for service in services:
        is_verified = whitelist.check(service.package_name)
        service.is_verified = is_verified
        service.last_seen = datetime.utcnow()

        if is_verified:
            verified_count += 1
            service.risk_score = 0
        else:
            unknown_count += 1
            service.risk_score = 60  # Unknown = medium risk
            max_risk = max(max_risk, service.risk_score)

        db.merge(service)

    db.commit()

    threat_level = assessment.level_from_score(max_risk)

    return ScanResult(
        total_services=len(services),
        verified_services=verified_count,
        unknown_services=unknown_count,
        threat_level=threat_level,
        risk_score=max_risk,
        timestamp=datetime.utcnow()
    )
```

## Alerts Router (app/routers/alerts.py)

```python
from fastapi import APIRouter, Depends, WebSocket
from sqlalchemy.orm import Session
from database import get_db, Alert
from app.models import AlertResponse
from typing import List
import json

router = APIRouter()
active_connections = []

@router.websocket("/ws/alerts")
async def websocket_alerts(websocket: WebSocket):
    """WebSocket connection for real-time alerts"""
    await websocket.accept()
    active_connections.append(websocket)
    try:
        while True:
            # Keep connection alive, receive any messages
            data = await websocket.receive_text()
    except Exception:
        active_connections.remove(websocket)

async def broadcast_alert(alert_data: dict):
    """Broadcast an alert to all connected clients"""
    for connection in active_connections:
        try:
            await connection.send_json(alert_data)
        except Exception:
            pass

@router.get("/alerts", response_model=List[AlertResponse])
async def get_alerts(limit: int = 50, db: Session = Depends(get_db)):
    """Get recent alerts"""
    alerts = db.query(Alert).order_by(Alert.created_at.desc()).limit(limit).all()
    return alerts

@router.post("/alerts/{alert_id}/ack")
async def acknowledge_alert(alert_id: int, db: Session = Depends(get_db)):
    """Acknowledge (dismiss) an alert"""
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if alert:
        alert.acknowledged = True
        db.commit()
    return {"status": "acknowledged"}
```

## ML Router (app/routers/ml.py)

```python
from fastapi import APIRouter
from app.models import EnvironmentResponse
from models.audio_classifier import NoiseClassifier

router = APIRouter()
classifier = NoiseClassifier()

@router.get("/ml/environment", response_model=EnvironmentResponse)
async def get_environment():
    """Get current environment classification"""
    # Run inference on latest audio window
    public_prob, private_prob = classifier.classify_latest()

    classification = "public" if public_prob > private_prob else "private"
    confidence = max(public_prob, private_prob)

    return EnvironmentResponse(
        public_probability=float(public_prob),
        private_probability=float(private_prob),
        classification=classification,
        confidence=float(confidence)
    )

@router.post("/ml/train")
async def trigger_training():
    """Trigger retraining of the ML model (admin only)"""
    # Placeholder for retraining endpoint
    return {"status": "training started"}
```

## Background Monitoring (app/services/background_scanner.py)

```python
import asyncio
from app.services.process_monitor import ProcessMonitor
from app.services.whitelist import WhitelistChecker
from database import SessionLocal
from app.routers.alerts import broadcast_alert
from datetime import datetime
import os

SCAN_INTERVAL = int(os.getenv("SCAN_INTERVAL_SECONDS", "60"))

async def start_background_scanner():
    """Start continuous background monitoring"""
    while True:
        try:
            db = SessionLocal()
            monitor = ProcessMonitor(db)
            whitelist = WhitelistChecker(db)

            services = monitor.scan()

            for service in services:
                is_verified = whitelist.check(service.package_name)

                if not is_verified and service.risk_score >= 80:
                    # Broadcast critical alert
                    await broadcast_alert({
                        "type": "threat_detected",
                        "service": service.package_name,
                        "threat_level": "critical",
                        "timestamp": datetime.utcnow().isoformat()
                    })

            db.close()
        except Exception as e:
            print(f"Scanner error: {e}")

        await asyncio.sleep(SCAN_INTERVAL)
```
